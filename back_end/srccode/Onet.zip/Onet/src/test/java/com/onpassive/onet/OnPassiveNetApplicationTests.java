package com.onpassive.onet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnPassiveNetApplicationTests {

	@Test
	void contextLoads() {
	}

}
