package com.onpassive.onet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onpassive.onet.entity.SubComment;

public interface SubCommentRepository extends JpaRepository<SubComment, Integer> {

}
