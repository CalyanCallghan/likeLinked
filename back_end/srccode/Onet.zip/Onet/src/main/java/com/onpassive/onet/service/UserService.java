package com.onpassive.onet.service;

import java.util.List;

import com.onpassive.onet.entity.User;

public interface  UserService {
	List<User> findAll();
}
