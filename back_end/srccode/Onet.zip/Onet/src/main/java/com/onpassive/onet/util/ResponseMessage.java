package com.onpassive.onet.util;

import lombok.Data;

@Data
public class ResponseMessage {
	private String message;
}
