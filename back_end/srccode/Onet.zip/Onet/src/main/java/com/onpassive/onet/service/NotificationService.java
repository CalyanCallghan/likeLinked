package com.onpassive.onet.service;

import java.util.List;

import com.onpassive.onet.entity.Notification;

public interface NotificationService {
	public List<Notification> getNotifications();

}
